package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.Converters
import com.example.model.Currency
import com.example.model.PaymentMethod
import com.example.model.TransactionType
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("FinLedger", appName)
    }

    @Test
    fun `currency default is PKR`() {
        val pkr = Currency.fromCode("PKR")
        assertEquals("₨", pkr.symbol)
        assertEquals("Pakistan", pkr.country)
    }

    @Test
    fun `test converters roundtrip`() {
        val converters = Converters()
        val expense = TransactionType.EXPENSE
        val str = converters.fromTransactionType(expense)
        val converted = converters.toTransactionType(str)
        assertEquals(expense, converted)

        val jazzcash = PaymentMethod.JAZZCASH
        val methodStr = converters.fromPaymentMethod(jazzcash)
        val convertedMethod = converters.toPaymentMethod(methodStr)
        assertEquals(jazzcash, convertedMethod)
    }
}
