package com.example

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.BudgetsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.KhataScreen
import com.example.ui.screens.LedgerScreen
import com.example.ui.screens.PinLockScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.FinLedgerTheme
import com.example.ui.viewmodel.FinanceViewModel

enum class MainNavTab(val label: String) {
    HOME("Home"),
    LEDGER("Ledger"),
    ANALYTICS("Analytics"),
    KHATA("Khata"),
    SETTINGS("Settings"),
    BUDGETS("Budgets")
}

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: FinanceViewModel = viewModel()
            val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()
            val isUnlocked by viewModel.isUnlocked.collectAsStateWithLifecycle()

            val isDarkTheme = when (userSettings.themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }

            FinLedgerTheme(darkTheme = isDarkTheme) {
                val requiresLock = userSettings.isPinEnabled && !isUnlocked

                if (requiresLock) {
                    PinLockScreen(
                        correctPin = userSettings.pinCode,
                        isBiometricEnabled = userSettings.isBiometricEnabled,
                        onUnlocked = { viewModel.unlockApp() }
                    )
                } else {
                    MainAppContent(
                        viewModel = viewModel,
                        onLockApp = { viewModel.lockApp() }
                    )
                }
            }
        }
    }
}

@Composable
fun MainAppContent(
    viewModel: FinanceViewModel,
    onLockApp: () -> Unit
) {
    var currentTab by remember { mutableStateOf(MainNavTab.HOME) }

    // Hardware back button navigation handling
    BackHandler(enabled = currentTab != MainNavTab.HOME) {
        currentTab = MainNavTab.HOME
    }

    Scaffold(
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_bottom_nav")
            ) {
                NavigationBarItem(
                    selected = currentTab == MainNavTab.HOME,
                    onClick = { currentTab = MainNavTab.HOME },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    modifier = Modifier.testTag("nav_home")
                )
                NavigationBarItem(
                    selected = currentTab == MainNavTab.LEDGER,
                    onClick = { currentTab = MainNavTab.LEDGER },
                    icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Ledger") },
                    label = { Text("Ledger") },
                    modifier = Modifier.testTag("nav_ledger")
                )
                NavigationBarItem(
                    selected = currentTab == MainNavTab.ANALYTICS,
                    onClick = { currentTab = MainNavTab.ANALYTICS },
                    icon = { Icon(Icons.Default.BarChart, contentDescription = "Analytics") },
                    label = { Text("Analytics") },
                    modifier = Modifier.testTag("nav_analytics")
                )
                NavigationBarItem(
                    selected = currentTab == MainNavTab.KHATA,
                    onClick = { currentTab = MainNavTab.KHATA },
                    icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Khata") },
                    label = { Text("Khata") },
                    modifier = Modifier.testTag("nav_khata")
                )
                NavigationBarItem(
                    selected = currentTab == MainNavTab.SETTINGS,
                    onClick = { currentTab = MainNavTab.SETTINGS },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") },
                    modifier = Modifier.testTag("nav_settings")
                )
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentTab,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "tabTransition",
            modifier = Modifier.padding(innerPadding)
        ) { tab ->
            when (tab) {
                MainNavTab.HOME -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToLedger = { currentTab = MainNavTab.LEDGER },
                    onNavigateToBudgets = { currentTab = MainNavTab.BUDGETS },
                    onNavigateToKhata = { currentTab = MainNavTab.KHATA }
                )
                MainNavTab.LEDGER -> LedgerScreen(
                    viewModel = viewModel
                )
                MainNavTab.ANALYTICS -> AnalyticsScreen(
                    viewModel = viewModel
                )
                MainNavTab.KHATA -> KhataScreen(
                    viewModel = viewModel
                )
                MainNavTab.BUDGETS -> BudgetsScreen(
                    viewModel = viewModel
                )
                MainNavTab.SETTINGS -> SettingsScreen(
                    viewModel = viewModel,
                    onLockApp = onLockApp
                )
            }
        }
    }
}
