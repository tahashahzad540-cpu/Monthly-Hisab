package com.example.data.local

import androidx.room.TypeConverter
import com.example.model.KhataStatus
import com.example.model.KhataType
import com.example.model.PaymentMethod
import com.example.model.TransactionType

class Converters {
    @TypeConverter
    fun fromTransactionType(value: TransactionType): String = value.name

    @TypeConverter
    fun toTransactionType(value: String): TransactionType =
        try { TransactionType.valueOf(value) } catch (e: Exception) { TransactionType.EXPENSE }

    @TypeConverter
    fun fromPaymentMethod(value: PaymentMethod): String = value.name

    @TypeConverter
    fun toPaymentMethod(value: String): PaymentMethod =
        try { PaymentMethod.valueOf(value) } catch (e: Exception) { PaymentMethod.CASH }

    @TypeConverter
    fun fromKhataType(value: KhataType): String = value.name

    @TypeConverter
    fun toKhataType(value: String): KhataType =
        try { KhataType.valueOf(value) } catch (e: Exception) { KhataType.LENT }

    @TypeConverter
    fun fromKhataStatus(value: KhataStatus): String = value.name

    @TypeConverter
    fun toKhataStatus(value: String): KhataStatus =
        try { KhataStatus.valueOf(value) } catch (e: Exception) { KhataStatus.PENDING }
}
