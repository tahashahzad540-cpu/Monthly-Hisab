package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.model.KhataStatus
import com.example.model.KhataType
import com.example.model.PaymentMethod
import com.example.model.TransactionType

@Entity(
    tableName = "transactions",
    indices = [Index(value = ["timestamp"]), Index(value = ["categoryName"])]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amount: Double,
    val type: TransactionType,
    val categoryName: String,
    val categoryIcon: String,
    val categoryColor: Long,
    val paymentMethod: PaymentMethod,
    val timestamp: Long,
    val note: String = ""
)

@Entity(
    tableName = "categories",
    indices = [Index(value = ["name", "type"], unique = true)]
)
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: TransactionType,
    val iconName: String,
    val colorHex: Long,
    val isDefault: Boolean = false
)

@Entity(
    tableName = "budgets",
    indices = [Index(value = ["categoryName", "month", "year"], unique = true)]
)
data class BudgetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val categoryName: String,
    val monthlyLimit: Double,
    val month: Int,
    val year: Int
)

@Entity(
    tableName = "khata_records",
    indices = [Index(value = ["contactName"])]
)
data class KhataEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactName: String,
    val phoneNumber: String = "",
    val type: KhataType,
    val originalAmount: Double,
    val remainingAmount: Double,
    val dueDate: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val notes: String = "",
    val status: KhataStatus = KhataStatus.PENDING
)
