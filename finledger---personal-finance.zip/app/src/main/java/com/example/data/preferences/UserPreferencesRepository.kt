package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.Currency
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_settings")

data class UserSettings(
    val currency: Currency = Currency.PKR,
    val userName: String = "Taha",
    val pinCode: String = "",
    val isPinEnabled: Boolean = false,
    val isBiometricEnabled: Boolean = false,
    val budgetAlertsEnabled: Boolean = true,
    val themeMode: String = "SYSTEM", // "SYSTEM", "LIGHT", "DARK"
    val lastBackupTime: Long = 0L
)

class UserPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val CURRENCY = stringPreferencesKey("currency_code")
        val USER_NAME = stringPreferencesKey("user_name")
        val PIN_CODE = stringPreferencesKey("pin_code")
        val IS_PIN_ENABLED = booleanPreferencesKey("is_pin_enabled")
        val IS_BIOMETRIC_ENABLED = booleanPreferencesKey("is_biometric_enabled")
        val BUDGET_ALERTS_ENABLED = booleanPreferencesKey("budget_alerts_enabled")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LAST_BACKUP_TIME = longPreferencesKey("last_backup_time")
    }

    val userSettings: Flow<UserSettings> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            val currencyCode = preferences[PreferencesKeys.CURRENCY] ?: "PKR"
            val currency = Currency.fromCode(currencyCode)
            val userName = preferences[PreferencesKeys.USER_NAME] ?: "Taha"
            val pinCode = preferences[PreferencesKeys.PIN_CODE] ?: ""
            val isPinEnabled = preferences[PreferencesKeys.IS_PIN_ENABLED] ?: false
            val isBiometricEnabled = preferences[PreferencesKeys.IS_BIOMETRIC_ENABLED] ?: false
            val budgetAlertsEnabled = preferences[PreferencesKeys.BUDGET_ALERTS_ENABLED] ?: true
            val themeMode = preferences[PreferencesKeys.THEME_MODE] ?: "SYSTEM"
            val lastBackupTime = preferences[PreferencesKeys.LAST_BACKUP_TIME] ?: 0L

            UserSettings(
                currency = currency,
                userName = userName,
                pinCode = pinCode,
                isPinEnabled = isPinEnabled,
                isBiometricEnabled = isBiometricEnabled,
                budgetAlertsEnabled = budgetAlertsEnabled,
                themeMode = themeMode,
                lastBackupTime = lastBackupTime
            )
        }

    suspend fun updateCurrency(currency: Currency) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.CURRENCY] = currency.code
        }
    }

    suspend fun updateUserName(name: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.USER_NAME] = name
        }
    }

    suspend fun setPinCode(pin: String, enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.PIN_CODE] = pin
            preferences[PreferencesKeys.IS_PIN_ENABLED] = enabled
        }
    }

    suspend fun setBiometricEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.IS_BIOMETRIC_ENABLED] = enabled
        }
    }

    suspend fun setBudgetAlertsEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.BUDGET_ALERTS_ENABLED] = enabled
        }
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.THEME_MODE] = mode
        }
    }

    suspend fun updateLastBackupTime(timestamp: Long) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.LAST_BACKUP_TIME] = timestamp
        }
    }
}
