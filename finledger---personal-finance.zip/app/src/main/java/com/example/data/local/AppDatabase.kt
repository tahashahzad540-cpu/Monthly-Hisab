package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.BudgetDao
import com.example.data.local.dao.CategoryDao
import com.example.data.local.dao.KhataDao
import com.example.data.local.dao.TransactionDao
import com.example.data.local.entity.BudgetEntity
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.KhataEntity
import com.example.data.local.entity.TransactionEntity
import com.example.model.TransactionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        TransactionEntity::class,
        CategoryEntity::class,
        BudgetEntity::class,
        KhataEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun transactionDao(): TransactionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun budgetDao(): BudgetDao
    abstract fun khataDao(): KhataDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "finledger_db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        val defaultCategories = listOf(
            // Income
            CategoryEntity(name = "Salary", type = TransactionType.INCOME, iconName = "Work", colorHex = 0xFF10B981, isDefault = true),
            CategoryEntity(name = "Business", type = TransactionType.INCOME, iconName = "Store", colorHex = 0xFF059669, isDefault = true),
            CategoryEntity(name = "Freelancing", type = TransactionType.INCOME, iconName = "Laptop", colorHex = 0xFF047857, isDefault = true),
            CategoryEntity(name = "Gifts", type = TransactionType.INCOME, iconName = "CardGiftcard", colorHex = 0xFF34D399, isDefault = true),
            CategoryEntity(name = "Investment", type = TransactionType.INCOME, iconName = "TrendingUp", colorHex = 0xFF14B8A6, isDefault = true),
            CategoryEntity(name = "Other Income", type = TransactionType.INCOME, iconName = "Savings", colorHex = 0xFF10B981, isDefault = true),

            // Expenses
            CategoryEntity(name = "Grocery", type = TransactionType.EXPENSE, iconName = "ShoppingCart", colorHex = 0xFFEF4444, isDefault = true),
            CategoryEntity(name = "Bills & Utilities", type = TransactionType.EXPENSE, iconName = "ReceiptLong", colorHex = 0xFFF97316, isDefault = true),
            CategoryEntity(name = "Fuel / Transport", type = TransactionType.EXPENSE, iconName = "LocalGasStation", colorHex = 0xFFEAB308, isDefault = true),
            CategoryEntity(name = "Medical & Health", type = TransactionType.EXPENSE, iconName = "LocalHospital", colorHex = 0xFFEC4899, isDefault = true),
            CategoryEntity(name = "Online Shopping", type = TransactionType.EXPENSE, iconName = "ShoppingBag", colorHex = 0xFF8B5CF6, isDefault = true),
            CategoryEntity(name = "Food & Dining", type = TransactionType.EXPENSE, iconName = "Restaurant", colorHex = 0xFFF43F5E, isDefault = true),
            CategoryEntity(name = "Entertainment", type = TransactionType.EXPENSE, iconName = "Movie", colorHex = 0xFF6366F1, isDefault = true),
            CategoryEntity(name = "Education", type = TransactionType.EXPENSE, iconName = "School", colorHex = 0xFF3B82F6, isDefault = true),
            CategoryEntity(name = "Misc / Others", type = TransactionType.EXPENSE, iconName = "Category", colorHex = 0xFF64748B, isDefault = true)
        )
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    database.categoryDao().insertCategories(defaultCategories)
                }
            }
        }
    }
}
