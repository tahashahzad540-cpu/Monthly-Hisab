package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.BudgetEntity
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.KhataEntity
import com.example.data.local.entity.TransactionEntity
import com.example.model.KhataStatus
import com.example.model.KhataType
import com.example.model.PaymentMethod
import com.example.model.TransactionType
import kotlinx.coroutines.flow.Flow
import java.util.Calendar

class FinanceRepository(private val database: AppDatabase) {

    private val transactionDao = database.transactionDao()
    private val categoryDao = database.categoryDao()
    private val budgetDao = database.budgetDao()
    private val khataDao = database.khataDao()

    // Transactions
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()

    fun getTransactionsBetween(start: Long, end: Long): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsBetween(start, end)

    fun getRecentTransactions(limit: Int = 10): Flow<List<TransactionEntity>> =
        transactionDao.getRecentTransactions(limit)

    suspend fun insertTransaction(transaction: TransactionEntity): Long =
        transactionDao.insertTransaction(transaction)

    suspend fun updateTransaction(transaction: TransactionEntity) =
        transactionDao.updateTransaction(transaction)

    suspend fun deleteTransaction(transaction: TransactionEntity) =
        transactionDao.deleteTransaction(transaction)

    suspend fun deleteTransactionById(id: Long) =
        transactionDao.deleteTransactionById(id)

    // Categories
    val allCategories: Flow<List<CategoryEntity>> = categoryDao.getAllCategories()

    fun getCategoriesByType(type: TransactionType): Flow<List<CategoryEntity>> =
        categoryDao.getCategoriesByType(type)

    suspend fun insertCategory(category: CategoryEntity): Long =
        categoryDao.insertCategory(category)

    suspend fun updateCategory(category: CategoryEntity) =
        categoryDao.updateCategory(category)

    suspend fun deleteCategory(category: CategoryEntity) =
        categoryDao.deleteCategory(category)

    suspend fun deleteCategoryById(id: Long) =
        categoryDao.deleteCategoryById(id)

    // Budgets
    val allBudgets: Flow<List<BudgetEntity>> = budgetDao.getAllBudgets()

    fun getBudgetsForMonth(month: Int, year: Int): Flow<List<BudgetEntity>> =
        budgetDao.getBudgetsForMonth(month, year)

    suspend fun setBudget(categoryName: String, monthlyLimit: Double, month: Int, year: Int) {
        val budget = BudgetEntity(
            categoryName = categoryName,
            monthlyLimit = monthlyLimit,
            month = month,
            year = year
        )
        budgetDao.insertOrUpdateBudget(budget)
    }

    suspend fun deleteBudgetById(id: Long) =
        budgetDao.deleteBudgetById(id)

    // Khata (Debt & Ledger)
    val allKhata: Flow<List<KhataEntity>> = khataDao.getAllKhata()

    fun getKhataByType(type: KhataType): Flow<List<KhataEntity>> =
        khataDao.getKhataByType(type)

    suspend fun insertKhata(khata: KhataEntity): Long =
        khataDao.insertKhata(khata)

    suspend fun updateKhata(khata: KhataEntity) =
        khataDao.updateKhata(khata)

    suspend fun deleteKhata(khata: KhataEntity) =
        khataDao.deleteKhata(khata)

    suspend fun deleteKhataById(id: Long) =
        khataDao.deleteKhataById(id)

    suspend fun recordKhataPayment(khataId: Long, paidAmount: Double) {
        val record = khataDao.getKhataById(khataId) ?: return
        val newRemaining = (record.remainingAmount - paidAmount).coerceAtLeast(0.0)
        val newStatus = if (newRemaining <= 0.0) KhataStatus.SETTLED else KhataStatus.PARTIALLY_PAID
        khataDao.updateKhata(record.copy(remainingAmount = newRemaining, status = newStatus))
    }

    // Seed realistic sample data if empty
    suspend fun seedSampleDataIfEmpty() {
        if (categoryDao.getCategoryCount() == 0) {
            categoryDao.insertCategories(AppDatabase.defaultCategories)
        }

        // Add demo budgets for current month if none exist
        val cal = Calendar.getInstance()
        val currentMonth = cal.get(Calendar.MONTH) + 1
        val currentYear = cal.get(Calendar.YEAR)

        budgetDao.insertOrUpdateBudget(
            BudgetEntity(categoryName = "Grocery", monthlyLimit = 35000.0, month = currentMonth, year = currentYear)
        )
        budgetDao.insertOrUpdateBudget(
            BudgetEntity(categoryName = "Fuel / Transport", monthlyLimit = 15000.0, month = currentMonth, year = currentYear)
        )
        budgetDao.insertOrUpdateBudget(
            BudgetEntity(categoryName = "Bills & Utilities", monthlyLimit = 25000.0, month = currentMonth, year = currentYear)
        )
        budgetDao.insertOrUpdateBudget(
            BudgetEntity(categoryName = "Food & Dining", monthlyLimit = 12000.0, month = currentMonth, year = currentYear)
        )

        // Add initial sample transactions if none
        val now = System.currentTimeMillis()
        val dayMillis = 86_400_000L

        val demoTransactions = listOf(
            TransactionEntity(
                title = "Monthly Salary",
                amount = 185000.0,
                type = TransactionType.INCOME,
                categoryName = "Salary",
                categoryIcon = "Work",
                categoryColor = 0xFF10B981,
                paymentMethod = PaymentMethod.BANK_TRANSFER,
                timestamp = now - (dayMillis * 12),
                note = "Tech Company Monthly Direct Deposit"
            ),
            TransactionEntity(
                title = "Freelance Mobile App Project",
                amount = 45000.0,
                type = TransactionType.INCOME,
                categoryName = "Freelancing",
                categoryIcon = "Laptop",
                categoryColor = 0xFF047857,
                paymentMethod = PaymentMethod.EASYPAISA,
                timestamp = now - (dayMillis * 4),
                note = "Milestone 2 Delivery"
            ),
            TransactionEntity(
                title = "Monthly Grocery Stock",
                amount = 21500.0,
                type = TransactionType.EXPENSE,
                categoryName = "Grocery",
                categoryIcon = "ShoppingCart",
                categoryColor = 0xFFEF4444,
                paymentMethod = PaymentMethod.CASH,
                timestamp = now - (dayMillis * 8),
                note = "Supermarket monthly rations"
            ),
            TransactionEntity(
                title = "Electricity & Internet Bill",
                amount = 18200.0,
                type = TransactionType.EXPENSE,
                categoryName = "Bills & Utilities",
                categoryIcon = "ReceiptLong",
                categoryColor = 0xFFF97316,
                paymentMethod = PaymentMethod.JAZZCASH,
                timestamp = now - (dayMillis * 5),
                note = "LESCO & Fiber Wi-Fi bill paid"
            ),
            TransactionEntity(
                title = "Fuel refill & Car Wash",
                amount = 7500.0,
                type = TransactionType.EXPENSE,
                categoryName = "Fuel / Transport",
                categoryIcon = "LocalGasStation",
                categoryColor = 0xFFEAB308,
                paymentMethod = PaymentMethod.CREDIT_CARD,
                timestamp = now - (dayMillis * 2),
                note = "Total Parco station"
            ),
            TransactionEntity(
                title = "Family Dinner & Barbecue",
                amount = 6400.0,
                type = TransactionType.EXPENSE,
                categoryName = "Food & Dining",
                categoryIcon = "Restaurant",
                categoryColor = 0xFFF43F5E,
                paymentMethod = PaymentMethod.RAAST,
                timestamp = now - (dayMillis * 1),
                note = "Weekend gathering"
            ),
            TransactionEntity(
                title = "Pharmacy & Vitamins",
                amount = 3200.0,
                type = TransactionType.EXPENSE,
                categoryName = "Medical & Health",
                categoryIcon = "LocalHospital",
                categoryColor = 0xFFEC4899,
                paymentMethod = PaymentMethod.CASH,
                timestamp = now - (3600_000L * 5),
                note = "Prescription medicines"
            )
        )
        transactionDao.insertTransactions(demoTransactions)

        // Seed demo Khata records
        val demoKhata = listOf(
            KhataEntity(
                contactName = "Ahmed Khan",
                phoneNumber = "+92 300 1234567",
                type = KhataType.LENT,
                originalAmount = 25000.0,
                remainingAmount = 15000.0,
                dueDate = now + (dayMillis * 10),
                createdAt = now - (dayMillis * 15),
                notes = "Personal emergency loan",
                status = KhataStatus.PARTIALLY_PAID
            ),
            KhataEntity(
                contactName = "Zubair Hardware Store",
                phoneNumber = "+92 321 7654321",
                type = KhataType.BORROWED,
                originalAmount = 8500.0,
                remainingAmount = 8500.0,
                dueDate = now + (dayMillis * 5),
                createdAt = now - (dayMillis * 3),
                notes = "House repair supplies on credit",
                status = KhataStatus.PENDING
            ),
            KhataEntity(
                contactName = "Usman Malik (Colleague)",
                phoneNumber = "+92 333 9876543",
                type = KhataType.LENT,
                originalAmount = 5000.0,
                remainingAmount = 5000.0,
                dueDate = now + (dayMillis * 14),
                createdAt = now - (dayMillis * 7),
                notes = "Shared office lunch bill contribution",
                status = KhataStatus.PENDING
            )
        )
        khataDao.insertKhataList(demoKhata)
    }

    suspend fun clearAllData() {
        transactionDao.clearAll()
        khataDao.clearAll()
    }
}
