package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme Colors
val PrimaryLight = Color(0xFF0D3B2E)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFD1E8DE)
val OnPrimaryContainerLight = Color(0xFF042018)

val SecondaryLight = Color(0xFF3B6B5D)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFDBE7E2)
val OnSecondaryContainerLight = Color(0xFF132A23)

val TertiaryLight = Color(0xFF10B981)
val OnTertiaryLight = Color(0xFFFFFFFF)

val BackgroundLight = Color(0xFFF8FAF9)
val OnBackgroundLight = Color(0xFF191C1B)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF191C1B)
val SurfaceVariantLight = Color(0xFFE4ECE8)
val OnSurfaceVariantLight = Color(0xFF434E49)

// Dark Scheme Colors
val PrimaryDark = Color(0xFF8AD7BA)
val OnPrimaryDark = Color(0xFF003828)
val PrimaryContainerDark = Color(0xFF0D3B2E)
val OnPrimaryContainerDark = Color(0xFFD1E8DE)

val SecondaryDark = Color(0xFFB1CCC1)
val OnSecondaryDark = Color(0xFF1C352D)
val SecondaryContainerDark = Color(0xFF334C43)
val OnSecondaryContainerDark = Color(0xFFDBE7E2)

val TertiaryDark = Color(0xFF34D399)
val OnTertiaryDark = Color(0xFF003825)

val BackgroundDark = Color(0xFF111413)
val OnBackgroundDark = Color(0xFFE1E3E1)
val SurfaceDark = Color(0xFF191C1B)
val OnSurfaceDark = Color(0xFFE1E3E1)
val SurfaceVariantDark = Color(0xFF404944)
val OnSurfaceVariantDark = Color(0xFFC0C9C3)

// Semantic Finance Colors
val IncomeGreen = Color(0xFF10B981)
val ExpenseRed = Color(0xFFEF4444)
val DebtOrange = Color(0xFFF59E0B)
val TransferBlue = Color(0xFF3B82F6)
