package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.BudgetEntity
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.TransactionEntity
import com.example.model.Currency
import com.example.model.KhataType
import com.example.model.PaymentMethod
import com.example.model.TransactionType
import com.example.ui.components.CategoryIconHelper
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditTransactionSheet(
    existingTransaction: TransactionEntity? = null,
    categories: List<CategoryEntity>,
    budgets: List<BudgetEntity>,
    categorySpentMap: Map<String, Double>,
    currency: Currency,
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        amount: Double,
        type: TransactionType,
        categoryName: String,
        categoryIcon: String,
        categoryColor: Long,
        paymentMethod: PaymentMethod,
        timestamp: Long,
        note: String
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current

    var type by remember { mutableStateOf(existingTransaction?.type ?: TransactionType.EXPENSE) }
    var amountText by remember { mutableStateOf(existingTransaction?.let { "%.0f".format(it.amount) } ?: "") }
    var title by remember { mutableStateOf(existingTransaction?.title ?: "") }
    var note by remember { mutableStateOf(existingTransaction?.note ?: "") }
    var selectedMethod by remember { mutableStateOf(existingTransaction?.paymentMethod ?: PaymentMethod.CASH) }
    var timestamp by remember { mutableLongStateOf(existingTransaction?.timestamp ?: System.currentTimeMillis()) }

    val filteredCategories = remember(categories, type) {
        categories.filter { it.type == type }
    }

    var selectedCategory by remember(filteredCategories) {
        val existing = filteredCategories.firstOrNull { it.name == existingTransaction?.categoryName }
        mutableStateOf(existing ?: filteredCategories.firstOrNull())
    }

    var amountError by remember { mutableStateOf<String?>(null) }
    var showAddCategoryDialog by remember { mutableStateOf(false) }

    // Real-time budget warning calculation
    val currentAmount = amountText.toDoubleOrNull() ?: 0.0
    val activeBudget = budgets.firstOrNull { it.categoryName == selectedCategory?.name }
    val currentSpent = categorySpentMap[selectedCategory?.name] ?: 0.0
    val projectedSpent = if (type == TransactionType.EXPENSE) currentSpent + currentAmount else currentSpent
    val budgetWarning = remember(activeBudget, projectedSpent, currentAmount) {
        if (activeBudget != null && type == TransactionType.EXPENSE && currentAmount > 0) {
            val limit = activeBudget.monthlyLimit
            when {
                projectedSpent > limit -> "Exceeds monthly budget of ${currency.symbol}%,.0f by ${currency.symbol}%,.0f!".format(limit, projectedSpent - limit)
                projectedSpent >= (limit * 0.8) -> "Warning: This transaction will use ${(projectedSpent / limit * 100).toInt()}% of your monthly ${selectedCategory?.name} budget."
                else -> null
            }
        } else null
    }

    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (existingTransaction == null) "Add Transaction" else "Edit Transaction",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Type Toggle (Expense / Income)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(4.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (type == TransactionType.EXPENSE) Color(0xFFEF4444) else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { type = TransactionType.EXPENSE }
                ) {
                    Text(
                        text = "Expense",
                        style = MaterialTheme.typography.titleSmall,
                        color = if (type == TransactionType.EXPENSE) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 10.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (type == TransactionType.INCOME) Color(0xFF10B981) else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { type = TransactionType.INCOME }
                ) {
                    Text(
                        text = "Income",
                        style = MaterialTheme.typography.titleSmall,
                        color = if (type == TransactionType.INCOME) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 10.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Amount input
            OutlinedTextField(
                value = amountText,
                onValueChange = {
                    amountText = it.filter { char -> char.isDigit() || char == '.' }
                    amountError = null
                },
                label = { Text("Amount (${currency.code}) *") },
                prefix = { Text("${currency.symbol} ", fontWeight = FontWeight.Bold) },
                isError = amountError != null,
                supportingText = amountError?.let { { Text(it) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("amount_input")
            )

            // Quick add amount pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(500, 1000, 2500, 5000, 10000).forEach { pillAmount ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.clickable {
                            val current = amountText.toDoubleOrNull() ?: 0.0
                            amountText = (current + pillAmount).toInt().toString()
                        }
                    ) {
                        Text(
                            text = "+$pillAmount",
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Budget Warning Banner
            AnimatedVisibility(visible = budgetWarning != null) {
                budgetWarning?.let { warning ->
                    val isExceeded = warning.contains("Exceeds")
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isExceeded) Color(0xFFEF4444).copy(alpha = 0.12f) else Color(0xFFF59E0B).copy(alpha = 0.12f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (isExceeded) Color(0xFFEF4444) else Color(0xFFF59E0B),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = warning,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isExceeded) Color(0xFFDC2626) else Color(0xFFD97706),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title / Description
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title / Purpose (e.g. Weekly Groceries)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("title_input")
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Category Selection Header
            Text(
                text = "Select Category",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                filteredCategories.forEach { cat ->
                    val isSelected = selectedCategory?.name == cat.name
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) Color(cat.colorHex).copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .border(
                                width = if (isSelected) 2.dp else 0.dp,
                                color = if (isSelected) Color(cat.colorHex) else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { selectedCategory = cat }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color(cat.colorHex)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = CategoryIconHelper.getIconByName(cat.iconName),
                                    contentDescription = cat.name,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = cat.name,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Payment Method Selection
            Text(
                text = "Payment Method",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PaymentMethod.entries.forEach { method ->
                    FilterChip(
                        selected = selectedMethod == method,
                        onClick = { selectedMethod = method },
                        label = { Text(method.displayName) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Date picker button
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        val c = Calendar.getInstance().apply { timeInMillis = timestamp }
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                c.set(Calendar.YEAR, y)
                                c.set(Calendar.MONTH, m)
                                c.set(Calendar.DAY_OF_MONTH, d)
                                timestamp = c.timeInMillis
                            },
                            c.get(Calendar.YEAR),
                            c.get(Calendar.MONTH),
                            c.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.CalendarToday,
                        contentDescription = "Date",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = dateFormat.format(Date(timestamp)),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Additional Notes
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Notes (Optional)") },
                maxLines = 2,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Submit Button
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0.0) {
                        amountError = "Please enter an amount greater than zero"
                        return@Button
                    }
                    val cat = selectedCategory ?: filteredCategories.firstOrNull() ?: CategoryEntity(
                        name = if (type == TransactionType.INCOME) "Other Income" else "Misc / Others",
                        type = type,
                        iconName = "Category",
                        colorHex = 0xFF64748B
                    )

                    onSave(
                        title.ifBlank { cat.name },
                        amt,
                        type,
                        cat.name,
                        cat.iconName,
                        cat.colorHex,
                        selectedMethod,
                        timestamp,
                        note
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_transaction_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (type == TransactionType.EXPENSE) Color(0xFFEF4444) else Color(0xFF10B981)
                )
            ) {
                Text(
                    text = if (existingTransaction == null) "Save Transaction" else "Update Transaction",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun AddKhataDialog(
    onDismiss: () -> Unit,
    currency: Currency,
    onSave: (contactName: String, phone: String, type: KhataType, amount: Double, dueDate: Long?, notes: String) -> Unit
) {
    val context = LocalContext.current
    var contactName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var khataType by remember { mutableStateOf(KhataType.LENT) }
    var amountText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf<Long?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "Add Khata / Debt Record", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Type selector
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(4.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (khataType == KhataType.LENT) Color(0xFF10B981) else Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { khataType = KhataType.LENT }
                    ) {
                        Text(
                            text = "Lent (ادھار دیا)",
                            color = if (khataType == KhataType.LENT) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (khataType == KhataType.BORROWED) Color(0xFFF97316) else Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { khataType = KhataType.BORROWED }
                    ) {
                        Text(
                            text = "Borrowed (ادھار لیا)",
                            color = if (khataType == KhataType.BORROWED) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = contactName,
                    onValueChange = { contactName = it },
                    label = { Text("Contact / Person Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("khata_contact_name")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number (Optional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Amount (${currency.code}) *") },
                    prefix = { Text("${currency.symbol} ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("khata_amount")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Due Date selector
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val c = Calendar.getInstance()
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    c.set(Calendar.YEAR, y)
                                    c.set(Calendar.MONTH, m)
                                    c.set(Calendar.DAY_OF_MONTH, d)
                                    dueDate = c.timeInMillis
                                },
                                c.get(Calendar.YEAR),
                                c.get(Calendar.MONTH),
                                c.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = dueDate?.let { "Due: ${dateFormat.format(Date(it))}" } ?: "Select Due Date (Optional)",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Reason") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                errorMessage?.let {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (contactName.isBlank()) {
                        errorMessage = "Please enter contact name"
                        return@Button
                    }
                    if (amt == null || amt <= 0) {
                        errorMessage = "Please enter a valid amount"
                        return@Button
                    }
                    onSave(contactName.trim(), phone.trim(), khataType, amt, dueDate, notes.trim())
                },
                modifier = Modifier.testTag("save_khata_btn")
            ) {
                Text("Save Khata")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SetBudgetDialog(
    categories: List<CategoryEntity>,
    currency: Currency,
    initialCategory: String? = null,
    onDismiss: () -> Unit,
    onSave: (categoryName: String, monthlyLimit: Double) -> Unit
) {
    val expenseCategories = remember(categories) {
        categories.filter { it.type == TransactionType.EXPENSE }
    }
    var selectedCategory by remember {
        mutableStateOf(expenseCategories.firstOrNull { it.name == initialCategory } ?: expenseCategories.firstOrNull())
    }
    var limitText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "Set Category Budget", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "Set a monthly spending limit to receive visual and push alerts when nearing or exceeding the limit.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text("Select Category:", style = MaterialTheme.typography.labelSmall)
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    expenseCategories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory?.name == cat.name,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat.name) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = limitText,
                    onValueChange = { limitText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Monthly Budget Limit (${currency.code}) *") },
                    prefix = { Text("${currency.symbol} ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("budget_limit_input")
                )

                error?.let {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val limit = limitText.toDoubleOrNull()
                    if (selectedCategory == null) {
                        error = "Please choose a category"
                        return@Button
                    }
                    if (limit == null || limit <= 0) {
                        error = "Please enter an amount > 0"
                        return@Button
                    }
                    onSave(selectedCategory!!.name, limit)
                },
                modifier = Modifier.testTag("save_budget_btn")
            ) {
                Text("Set Budget")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun RecordKhataPaymentDialog(
    contactName: String,
    remainingAmount: Double,
    currency: Currency,
    onDismiss: () -> Unit,
    onConfirm: (paidAmount: Double) -> Unit
) {
    var amountText by remember { mutableStateOf("%.0f".format(remainingAmount)) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "Record Payment for $contactName", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "Total due remaining: ${currency.symbol}%,.0f".format(remainingAmount),
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Payment Received / Given (${currency.code})") },
                    prefix = { Text("${currency.symbol} ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0) {
                        error = "Enter a valid payment amount"
                        return@Button
                    }
                    onConfirm(amt)
                }
            ) {
                Text("Confirm Payment")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
