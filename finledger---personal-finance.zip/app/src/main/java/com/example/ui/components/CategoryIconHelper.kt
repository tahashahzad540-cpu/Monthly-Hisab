package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.graphics.vector.ImageVector

object CategoryIconHelper {
    fun getIconByName(iconName: String): ImageVector {
        return when (iconName) {
            "Work" -> Icons.Default.Work
            "Store" -> Icons.Default.Store
            "Laptop" -> Icons.Default.Laptop
            "CardGiftcard" -> Icons.Default.CardGiftcard
            "TrendingUp" -> Icons.AutoMirrored.Filled.TrendingUp
            "Savings" -> Icons.Default.Savings
            "ShoppingCart" -> Icons.Default.ShoppingCart
            "ReceiptLong" -> Icons.Default.ReceiptLong
            "LocalGasStation" -> Icons.Default.LocalGasStation
            "LocalHospital" -> Icons.Default.LocalHospital
            "ShoppingBag" -> Icons.Default.ShoppingBag
            "Restaurant" -> Icons.Default.Restaurant
            "Movie" -> Icons.Default.Movie
            "School" -> Icons.Default.School
            "Business" -> Icons.Default.Business
            "AccountBalance" -> Icons.Default.AccountBalance
            "Home" -> Icons.Default.Home
            "Fastfood" -> Icons.Default.Fastfood
            "DirectionsCar" -> Icons.Default.DirectionsCar
            "Payments" -> Icons.Default.Payments
            "AttachMoney" -> Icons.Default.AttachMoney
            else -> Icons.Default.Category
        }
    }

    val availableIcons = listOf(
        "ShoppingCart", "ReceiptLong", "LocalGasStation", "LocalHospital",
        "ShoppingBag", "Restaurant", "Movie", "School", "Fastfood",
        "DirectionsCar", "Home", "Work", "Store", "Laptop",
        "CardGiftcard", "TrendingUp", "Savings", "Payments", "Category"
    )

    val availableColors = listOf(
        0xFF10B981, // Emerald green
        0xFF059669, // Forest green
        0xFF3B82F6, // Blue
        0xFF6366F1, // Indigo
        0xFF8B5CF6, // Purple
        0xFFEC4899, // Pink
        0xFFEF4444, // Red
        0xFFF97316, // Orange
        0xFFEAB308, // Amber
        0xFF14B8A6, // Teal
        0xFF06B6D4, // Cyan
        0xFF64748B  // Slate
    )
}
