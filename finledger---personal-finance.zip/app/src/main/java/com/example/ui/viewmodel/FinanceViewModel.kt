package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.BudgetEntity
import com.example.data.local.entity.CategoryEntity
import com.example.data.local.entity.KhataEntity
import com.example.data.local.entity.TransactionEntity
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.preferences.UserSettings
import com.example.data.repository.FinanceRepository
import com.example.model.Currency
import com.example.model.KhataStatus
import com.example.model.KhataType
import com.example.model.PaymentMethod
import com.example.model.TimeFrame
import com.example.model.TransactionType
import com.example.ui.components.ComparisonBarItem
import com.example.ui.components.PieChartSlice
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class DashboardSummary(
    val availableBalance: Double = 0.0,
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val savingsRate: Int = 0
)

data class KhataSummary(
    val totalToReceive: Double = 0.0, // Lent
    val totalToPay: Double = 0.0,     // Borrowed
    val netBalance: Double = 0.0
)

data class FilterCriteria(
    val timeFrame: TimeFrame,
    val month: Int,
    val year: Int,
    val query: String,
    val type: TransactionType?
)

class FinanceViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = FinanceRepository(database)
    private val preferencesRepository = UserPreferencesRepository(application)

    // User settings
    val userSettings: StateFlow<UserSettings> = preferencesRepository.userSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    // App Lock state
    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    // Filters
    private val _timeFrame = MutableStateFlow(TimeFrame.MONTHLY)
    val timeFrame: StateFlow<TimeFrame> = _timeFrame.asStateFlow()

    private val cal = Calendar.getInstance()
    private val _selectedMonth = MutableStateFlow(cal.get(Calendar.MONTH) + 1)
    val selectedMonth: StateFlow<Int> = _selectedMonth.asStateFlow()

    private val _selectedYear = MutableStateFlow(cal.get(Calendar.YEAR))
    val selectedYear: StateFlow<Int> = _selectedYear.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _typeFilter = MutableStateFlow<TransactionType?>(null)
    val typeFilter: StateFlow<TransactionType?> = _typeFilter.asStateFlow()

    // Combined filter flow
    private val filterCriteria: Flow<FilterCriteria> = combine(
        _timeFrame,
        _selectedMonth,
        _selectedYear,
        _searchQuery,
        _typeFilter
    ) { tf, m, y, q, type ->
        FilterCriteria(timeFrame = tf, month = m, year = y, query = q, type = type)
    }

    // Data streams
    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCategories: StateFlow<List<CategoryEntity>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allBudgets: StateFlow<List<BudgetEntity>> = repository.allBudgets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allKhata: StateFlow<List<KhataEntity>> = repository.allKhata
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered transactions
    val filteredTransactions: StateFlow<List<TransactionEntity>> = allTransactions
        .combine(filterCriteria) { txs, criteria ->
            val calInstance = Calendar.getInstance()
            txs.filter { tx ->
                calInstance.timeInMillis = tx.timestamp
                val txYear = calInstance.get(Calendar.YEAR)
                val txMonth = calInstance.get(Calendar.MONTH) + 1
                val txDay = calInstance.get(Calendar.DAY_OF_YEAR)

                val matchesTime = when (criteria.timeFrame) {
                    TimeFrame.DAILY -> {
                        val today = Calendar.getInstance()
                        txYear == today.get(Calendar.YEAR) && txDay == today.get(Calendar.DAY_OF_YEAR)
                    }
                    TimeFrame.MONTHLY -> txYear == criteria.year && txMonth == criteria.month
                    TimeFrame.YEARLY -> txYear == criteria.year
                }

                val matchesQuery = criteria.query.isBlank() ||
                    tx.title.contains(criteria.query, ignoreCase = true) ||
                    tx.categoryName.contains(criteria.query, ignoreCase = true) ||
                    tx.note.contains(criteria.query, ignoreCase = true)

                val matchesType = criteria.type == null || tx.type == criteria.type

                matchesTime && matchesQuery && matchesType
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Summary Totals
    val dashboardSummary: StateFlow<DashboardSummary> = filteredTransactions
        .map { filtered ->
            val income = filtered.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
            val expense = filtered.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
            val available = income - expense
            val rate = if (income > 0) (((income - expense) / income) * 100).toInt().coerceIn(0, 100) else 0
            DashboardSummary(
                availableBalance = available,
                totalIncome = income,
                totalExpense = expense,
                savingsRate = rate
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardSummary())

    // Donut Chart Slices (Category Expense Breakdown)
    val expenseChartSlices: StateFlow<List<PieChartSlice>> = filteredTransactions
        .map { txs ->
            val expenses = txs.filter { it.type == TransactionType.EXPENSE }
            val grouped = expenses.groupBy { it.categoryName }
            grouped.map { (catName, list) ->
                val total = list.sumOf { it.amount }
                val colorHex = list.firstOrNull()?.categoryColor ?: 0xFFEF4444
                PieChartSlice(
                    label = catName,
                    value = total,
                    color = androidx.compose.ui.graphics.Color(colorHex)
                )
            }.sortedByDescending { it.value }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Bar Chart comparison (Last 6 Months)
    val monthlyTrends: StateFlow<List<ComparisonBarItem>> = allTransactions
        .map { txs ->
            val monthNames = arrayOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
            val list = mutableListOf<ComparisonBarItem>()

            for (i in 5 downTo 0) {
                val c = Calendar.getInstance()
                c.add(Calendar.MONTH, -i)
                val m = c.get(Calendar.MONTH) + 1
                val y = c.get(Calendar.YEAR)
                val label = monthNames[m - 1]

                val inMonthTxs = txs.filter {
                    val txCal = Calendar.getInstance().apply { timeInMillis = it.timestamp }
                    txCal.get(Calendar.YEAR) == y && (txCal.get(Calendar.MONTH) + 1) == m
                }

                val inc = inMonthTxs.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
                val exp = inMonthTxs.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
                list.add(ComparisonBarItem(label = label, income = inc, expense = exp))
            }
            list
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Khata Summary
    val khataSummary: StateFlow<KhataSummary> = allKhata
        .map { records ->
            val toReceive = records.filter { it.type == KhataType.LENT && it.status != KhataStatus.SETTLED }.sumOf { it.remainingAmount }
            val toPay = records.filter { it.type == KhataType.BORROWED && it.status != KhataStatus.SETTLED }.sumOf { it.remainingAmount }
            KhataSummary(
                totalToReceive = toReceive,
                totalToPay = toPay,
                netBalance = toReceive - toPay
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), KhataSummary())

    // Category Spending vs Budget mapping
    val categorySpentMap: StateFlow<Map<String, Double>> = filteredTransactions
        .map { txs ->
            txs.filter { it.type == TransactionType.EXPENSE }
                .groupBy { it.categoryName }
                .mapValues { entry -> entry.value.sumOf { it.amount } }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    init {
        viewModelScope.launch {
            repository.seedSampleDataIfEmpty()
        }
    }

    // Actions
    fun unlockApp() {
        _isUnlocked.value = true
    }

    fun lockApp() {
        _isUnlocked.value = false
    }

    fun setTimeFrame(tf: TimeFrame) {
        _timeFrame.value = tf
    }

    fun setSelectedMonth(m: Int) {
        _selectedMonth.value = m
    }

    fun setSelectedYear(y: Int) {
        _selectedYear.value = y
    }

    fun setSearchQuery(q: String) {
        _searchQuery.value = q
    }

    fun setTypeFilter(type: TransactionType?) {
        _typeFilter.value = type
    }

    fun addTransaction(
        title: String,
        amount: Double,
        type: TransactionType,
        categoryName: String,
        categoryIcon: String,
        categoryColor: Long,
        paymentMethod: PaymentMethod,
        timestamp: Long,
        note: String
    ) {
        viewModelScope.launch {
            val entity = TransactionEntity(
                title = title,
                amount = amount,
                type = type,
                categoryName = categoryName,
                categoryIcon = categoryIcon,
                categoryColor = categoryColor,
                paymentMethod = paymentMethod,
                timestamp = timestamp,
                note = note
            )
            repository.insertTransaction(entity)
        }
    }

    fun updateTransaction(tx: TransactionEntity) {
        viewModelScope.launch {
            repository.updateTransaction(tx)
        }
    }

    fun deleteTransaction(tx: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(tx)
        }
    }

    fun addCategory(name: String, type: TransactionType, iconName: String, colorHex: Long) {
        viewModelScope.launch {
            repository.insertCategory(
                CategoryEntity(
                    name = name,
                    type = type,
                    iconName = iconName,
                    colorHex = colorHex
                )
            )
        }
    }

    fun deleteCategory(cat: CategoryEntity) {
        viewModelScope.launch {
            repository.deleteCategory(cat)
        }
    }

    fun setBudget(categoryName: String, monthlyLimit: Double) {
        viewModelScope.launch {
            repository.setBudget(
                categoryName = categoryName,
                monthlyLimit = monthlyLimit,
                month = selectedMonth.value,
                year = selectedYear.value
            )
        }
    }

    fun deleteBudget(id: Long) {
        viewModelScope.launch {
            repository.deleteBudgetById(id)
        }
    }

    fun addKhata(
        contactName: String,
        phoneNumber: String,
        type: KhataType,
        amount: Double,
        dueDate: Long?,
        notes: String
    ) {
        viewModelScope.launch {
            repository.insertKhata(
                KhataEntity(
                    contactName = contactName,
                    phoneNumber = phoneNumber,
                    type = type,
                    originalAmount = amount,
                    remainingAmount = amount,
                    dueDate = dueDate,
                    notes = notes
                )
            )
        }
    }

    fun recordKhataPayment(khataId: Long, paidAmount: Double) {
        viewModelScope.launch {
            repository.recordKhataPayment(khataId, paidAmount)
        }
    }

    fun deleteKhata(khata: KhataEntity) {
        viewModelScope.launch {
            repository.deleteKhata(khata)
        }
    }

    fun updateCurrency(currency: Currency) {
        viewModelScope.launch {
            preferencesRepository.updateCurrency(currency)
        }
    }

    fun updateUserName(name: String) {
        viewModelScope.launch {
            preferencesRepository.updateUserName(name)
        }
    }

    fun setPin(pin: String, enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setPinCode(pin, enabled)
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setBiometricEnabled(enabled)
        }
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch {
            preferencesRepository.setThemeMode(mode)
        }
    }

    fun resetData() {
        viewModelScope.launch {
            repository.clearAllData()
            repository.seedSampleDataIfEmpty()
        }
    }
}
