package com.example.model

enum class TransactionType {
    EXPENSE,
    INCOME
}

enum class PaymentMethod(val displayName: String) {
    CASH("Cash"),
    BANK_TRANSFER("Bank Transfer"),
    EASYPAISA("Easypaisa"),
    JAZZCASH("JazzCash"),
    CREDIT_CARD("Credit/Debit Card"),
    RAAST("Raast / Digital");

    companion object {
        fun fromString(value: String): PaymentMethod {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) || it.displayName.equals(value, ignoreCase = true) }
                ?: CASH
        }
    }
}

enum class KhataType(val displayName: String, val urduLabel: String) {
    LENT("Lent (You Will Get)", "ادھار دیا / لینا ہے"),
    BORROWED("Borrowed (You Owe)", "ادھار لیا / دینا ہے")
}

enum class KhataStatus {
    PENDING,
    PARTIALLY_PAID,
    SETTLED
}

enum class TimeFrame(val label: String) {
    DAILY("Daily"),
    MONTHLY("Monthly"),
    YEARLY("Yearly")
}

enum class Currency(val code: String, val symbol: String, val country: String) {
    PKR("PKR", "₨", "Pakistan"),
    USD("USD", "$", "United States"),
    EUR("EUR", "€", "Eurozone"),
    GBP("GBP", "£", "United Kingdom"),
    AED("AED", "د.إ", "United Arab Emirates"),
    SAR("SAR", "﷼", "Saudi Arabia"),
    INR("INR", "₹", "India");

    companion object {
        fun fromCode(code: String): Currency {
            return entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: PKR
        }
    }
}
