package com.example.export

import android.content.Context
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.local.entity.TransactionEntity
import com.example.model.Currency
import com.example.model.TransactionType
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExportManager {

    fun exportToCsv(
        context: Context,
        transactions: List<TransactionEntity>,
        currency: Currency,
        periodName: String
    ): File? {
        return try {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            val fileName = "FinLedger_Statement_${periodName.replace(" ", "_")}_${System.currentTimeMillis()}.csv"
            val file = File(context.cacheDir, fileName)

            val writer = file.bufferedWriter()
            writer.write("ID,Date & Time,Type,Title,Category,Payment Method,Amount (${currency.code}),Note\n")

            for (tx in transactions) {
                val formattedDate = dateFormat.format(Date(tx.timestamp))
                val safeTitle = tx.title.replace(",", ";").replace("\"", "'")
                val safeNote = tx.note.replace(",", ";").replace("\"", "'")
                val line = "${tx.id},\"$formattedDate\",${tx.type.name},\"$safeTitle\",\"${tx.categoryName}\",\"${tx.paymentMethod.displayName}\",${tx.amount},\"$safeNote\"\n"
                writer.write(line)
            }
            writer.flush()
            writer.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun exportToPdf(
        context: Context,
        transactions: List<TransactionEntity>,
        currency: Currency,
        userName: String,
        periodName: String
    ): File? {
        return try {
            val pdfDocument = PdfDocument()
            val pageWidth = 595 // A4 standard width in points
            val pageHeight = 842 // A4 standard height in points
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val titlePaint = Paint().apply {
                color = AndroidColor.rgb(13, 59, 46) // Emerald dark #0D3B2E
                textSize = 20f
                isFakeBoldText = true
            }

            val subtitlePaint = Paint().apply {
                color = AndroidColor.DKGRAY
                textSize = 10f
            }

            val headerPaint = Paint().apply {
                color = AndroidColor.BLACK
                textSize = 11f
                isFakeBoldText = true
            }

            val rowPaint = Paint().apply {
                color = AndroidColor.BLACK
                textSize = 9.5f
            }

            val greenPaint = Paint().apply {
                color = AndroidColor.rgb(16, 185, 129)
                textSize = 9.5f
                isFakeBoldText = true
            }

            val redPaint = Paint().apply {
                color = AndroidColor.rgb(239, 68, 68)
                textSize = 9.5f
                isFakeBoldText = true
            }

            val linePaint = Paint().apply {
                color = AndroidColor.LTGRAY
                strokeWidth = 1f
            }

            val bgCardPaint = Paint().apply {
                color = AndroidColor.rgb(243, 244, 246)
            }

            // Header Banner
            canvas.drawRect(20f, 20f, (pageWidth - 20).toFloat(), 75f, bgCardPaint)
            canvas.drawText("FinLedger - Financial Statement", 35f, 48f, titlePaint)
            canvas.drawText("Generated for: $userName | Period: $periodName | Currency: ${currency.code}", 35f, 65f, subtitlePaint)

            // Summary Totals
            val totalIncome = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
            val totalExpense = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
            val netSavings = totalIncome - totalExpense

            canvas.drawRect(20f, 85f, (pageWidth - 20).toFloat(), 130f, bgCardPaint)
            canvas.drawText("Total Income: ${currency.symbol}${String.format(Locale.getDefault(), "%,.0f", totalIncome)}", 35f, 110f, greenPaint)
            canvas.drawText("Total Expense: ${currency.symbol}${String.format(Locale.getDefault(), "%,.0f", totalExpense)}", 220f, 110f, redPaint)
            canvas.drawText("Net Balance: ${currency.symbol}${String.format(Locale.getDefault(), "%,.0f", netSavings)}", 400f, 110f, headerPaint)

            // Table Header
            var yPos = 160f
            canvas.drawLine(20f, yPos - 15f, (pageWidth - 20).toFloat(), yPos - 15f, linePaint)
            canvas.drawText("Date", 25f, yPos, headerPaint)
            canvas.drawText("Title / Note", 100f, yPos, headerPaint)
            canvas.drawText("Category", 260f, yPos, headerPaint)
            canvas.drawText("Method", 380f, yPos, headerPaint)
            canvas.drawText("Amount", 480f, yPos, headerPaint)
            yPos += 8f
            canvas.drawLine(20f, yPos, (pageWidth - 20).toFloat(), yPos, linePaint)

            val dateFormat = SimpleDateFormat("dd MMM yy", Locale.getDefault())
            yPos += 18f

            for ((index, tx) in transactions.take(30).withIndex()) {
                if (yPos > pageHeight - 40f) break

                if (index % 2 == 1) {
                    canvas.drawRect(20f, yPos - 13f, (pageWidth - 20).toFloat(), yPos + 6f, bgCardPaint)
                }

                val formattedDate = dateFormat.format(Date(tx.timestamp))
                val titleSnippet = if (tx.title.length > 24) tx.title.substring(0, 22) + "..." else tx.title
                val categorySnippet = if (tx.categoryName.length > 18) tx.categoryName.substring(0, 16) + "..." else tx.categoryName

                canvas.drawText(formattedDate, 25f, yPos, rowPaint)
                canvas.drawText(titleSnippet, 100f, yPos, rowPaint)
                canvas.drawText(categorySnippet, 260f, yPos, rowPaint)
                canvas.drawText(tx.paymentMethod.displayName, 380f, yPos, rowPaint)

                val amountStr = "${if (tx.type == TransactionType.INCOME) "+" else "-"}${currency.symbol}${String.format(Locale.getDefault(), "%,.0f", tx.amount)}"
                canvas.drawText(amountStr, 480f, yPos, if (tx.type == TransactionType.INCOME) greenPaint else redPaint)

                yPos += 20f
            }

            // Footer
            canvas.drawLine(20f, (pageHeight - 35).toFloat(), (pageWidth - 20).toFloat(), (pageHeight - 35).toFloat(), linePaint)
            canvas.drawText("Generated via FinLedger App - Offline & Secure Personal Finance", 25f, (pageHeight - 20).toFloat(), subtitlePaint)

            pdfDocument.finishPage(page)

            val fileName = "FinLedger_Statement_${periodName.replace(" ", "_")}_${System.currentTimeMillis()}.pdf"
            val file = File(context.cacheDir, fileName)
            val outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            pdfDocument.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun shareExportedFile(context: Context, file: File, mimeType: String, title: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
